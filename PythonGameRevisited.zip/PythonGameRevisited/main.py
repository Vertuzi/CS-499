import time
from pymongo import MongoClient

class Player:
    def __init__(self, name, starting_room):
        self.name = name
        self.current_room = starting_room
        self.inventory = []

    def move(self, direction):
        next_room = self.current_room.get_connection(direction)
        return next_room

class Room:
    def __init__(self, name, connections, item=None):
        self.name = name
        self.connections = connections
        self.item = item

    def get_connection(self, direction):
        return self.connections.get(direction)

    def has_item(self):
        return self.item is not None

    def take_item(self):
        item = self.item
        self.item = None
        return item

class Game:
    def __init__(self):
        self.rooms = self.create_rooms()
        player_name = input("Enter your name, Brave adventurer: ")
        self.player = Player(player_name, self.rooms['Front Entrance'])
        self.start_time = time.time()
        self.db = MongoDBHandler()

    def create_rooms(self):
        return {
            'Front Entrance': Room('Front Entrance', {'East': 'Living Room'}),
            'Living Room': Room('Living Room', {'North': 'Bedroom', 'South': 'Library', 'East': 'Kitchen'}, 'Armor'),
            'Library': Room('Library', {'North': 'Living Room', 'East': 'Bookshelf'}, 'Shield'),
            'Bookshelf': Room('Bookshelf', {'West': 'Library'}, 'Spellbook'),
            'Bedroom': Room('Bedroom', {'South': 'Living Room', 'East': 'Closet'}, 'Boots'),
            'Closet': Room('Closet', {'West': 'Bedroom'}, 'Helmet'),
            'Kitchen': Room('Kitchen', {'West': 'Living Room', 'East': 'Cellar'}, 'Knife'),
            'Cellar': Room('Cellar', {'West': 'Kitchen'}, 'Dragon!')
        }

    def show_instructions(self):
        print("\nWelcome to the Dragon Text Adventure Game!")
        print("Collect 6 items to win the game, or be eaten by the dragon.")
        print("Move commands: go South, go North, go East, go West")
        print("Add to Inventory: get 'item name'\n")

    def show_status(self):
        room = self.player.current_room
        print(f"You are in the {room.name}")
        print(f"Inventory: {self.player.inventory}")
        if room.has_item():
            print(f"You see a {room.item}\n")

    def run(self):
        self.show_instructions()
        while True:
            self.show_status()

            if self.player.current_room.name == 'Cellar':
                if len(self.player.inventory) == 6:
                    print("🎉 Congratulations! 🎉 You have collected all items and defeated the dragon!")
                    elapsed_time = round(time.time() - self.start_time, 2)
                    print(f"⏱️ Time: {elapsed_time} seconds ⏱️")
                    self.db.save_score(self.player.name, elapsed_time)
                else:
                    print("🐉 NOM NOM... Game Over! 🐉")

                print('Thanks for playing! Hope you enjoyed it!')
                print("\n🏆 Leaderboard:")
                self.db.show_leaderboard()

                input("\nPress Enter to exit the game")
                break

            command = input("Enter your move: ").split()
            if not command:
                continue

            command = [c.capitalize() for c in command]
            action = command[0].lower()

            if action == 'exit':
                print('Thanks for playing!')
                break
            elif action == 'go' and len(command) == 2:
                direction = command[1]
                next_room_name = self.player.current_room.get_connection(direction)
                if next_room_name:
                    self.player.current_room = self.rooms[next_room_name]
                else:
                    print("You can't go that way.")
            elif action == 'get':
                item_requested = ' '.join(command[1:])
                room = self.player.current_room
                if room.has_item() and room.item.lower() == item_requested.lower():
                    self.player.inventory.append(room.take_item())
                    print(f"You picked up the {item_requested}!\n")
                else:
                    print("No such item here or incorrect item name.")
            else:
                print("Invalid command.")


class MongoDBHandler:
    def __init__(self):
        try:
            self.client = MongoClient("mongodb+srv://Player:cbxmuIystwNKlIHD@pythongamecluster.j7lllxy.mongodb.net/")  # mongodb+srv://Vertuzi:Jungle4free4m%40@pythongamecluster.j7lllxy.mongodb.net/ or local host mongodb://localhost:27017/
            self.db = self.client["PythonGame"]
            self.collection = self.db["leaderboard"]
        except Exception as e:
            print("Database connection failed:", e)

    def save_score(self, player_name, time_seconds):
        self.collection.insert_one({"name": player_name, "time": time_seconds})

    def show_leaderboard(self):
        leaderboard = self.collection.find().sort("time", 1).limit(5)
        for idx, entry in enumerate(leaderboard, start=1):
            print(f"{idx}. {entry['name']} - {entry['time']}s")


if __name__ == "__main__":
    game = Game()
    game.run()
